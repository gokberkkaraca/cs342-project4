Group Members
1) Kaan Sancak 21502708
2) Sabit Gökberk Karaca 21401862


How to run
1) Run Makefile by typing: make
2) Run the app by typing: ./ds <N> <infile.txt> 
   : where N is the Max Head Number and infile is the input file name
